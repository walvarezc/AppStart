package com.example.appnubedeluna

import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent as Intent

class MainActivity : AppCompatActivity() {
    private var edtUsername: EditText? = null
    private var edtPassword: EditText? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtUsername = findViewById(R.id.edtUsername)
        edtPassword = findViewById(R.id.edtPassword)

    }

    fun onlogin(botonLogin:View) {
        if (edtUsername!!.text.toString()== "lfa@email.com"){
            if (edtPassword!!.text.toString() =="1234"){
                val packageContext = ""
                val intento = Intent( this, WellcomeActivity::class.java)
                startActivity(intento)
            }
        }

    }


}